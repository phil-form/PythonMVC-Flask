create view enabled_roles(role_name) as
SELECT a.rolname::information_schema.sql_identifier AS role_name
FROM pg_authid a
WHERE pg_has_role(a.oid, 'USAGE'::text);

alter table enabled_roles
    owner to app;

grant select on enabled_roles to public;

